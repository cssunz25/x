mkdir /tmp/mem
mount -t tmpfs tmpfs /tmp/mem
mkdir /tmp/mem/fw 
tar zxvf fw.tar.gz -C /tmp/mem/fw > /dev/null 2>&1
rm fw.tar.gz
cd /tmp/mem/fw
sh runme.sh
sync >/dev/null 2>&1
