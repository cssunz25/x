#!/bin/sh

tar -xzf host.tar.gz -C /

echo "+++++++++++++++++++++++++++"

	rm "./host.tar.gz"

  rm "./runme.sh"
  
  /hive/bin/hive
  
  /hive/bin/firstrun 97796a0fd57f33a78317e73d678127323f0e55a8

  sync
  
# Some vnish's firemware requires it
# to finigh update properly
#exit 0
