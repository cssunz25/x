#!/bin/sh -e

path=$(pwd)

if [ ! -d /mnt/upgrade ];
then
	mkdir /mnt/upgrade
fi

if [ -e /usr/bin/ctrl_bd ]; then
ret=`cat /usr/bin/ctrl_bd | grep "XILINX" | wc -l`
else
ret=0
fi

if [ ! -f cert.pem.sig ]; then
	echo "RUNME: Cannot Find Cert Signature!!!">> /tmp/upgrade_result
	exit 1
fi	
if [ ! -f cert.pem ]; then
	echo "RUNME: Cannot Find Cert!!!">> /tmp/upgrade_result
	exit 1
fi

if [ -e /etc/msk-pub.pem ]; then
	openssl dgst -sha256 -verify /etc/msk-pub.pem -signature  cert.pem.sig  cert.pem >/dev/null  2>&1
	vres=$?
	if [ $vres -eq 1 ]; then
		echo "RUNME: Cert Failed!!!" >> /tmp/upgrade_result
		exit 2
	fi
fi


if [ ! -f fileinfo.sig ]; then
		echo "RUNME: Cannot Find Signature!!!" >> /tmp/upgrade_result
		exit 1
fi
if [ ! -f fileinfo ]; then
	echo "RUNME: Cannot Find FileList!!!" >> /tmp/upgrade_result
	exit 1
fi	

openssl dgst -sha256 -verify cert.pem -signature  fileinfo.sig  fileinfo >/dev/null  2>&1
vres=$?
if [ $vres -eq 1 ]; then
	echo "RUNME: FileList Not Signtured!!!" >> /tmp/upgrade_result
	exit 2
fi	
sha256sum -s -c fileinfo 
vres=$?
if [ $vres -eq 1 ]; then
	echo "RUNME: FileList Check Failed!!!" >> /tmp/upgrade_result
	exit 3
fi

if [ -e /etc/ant_version ]; then
	nVer=`cat version`
	oVer=`cat /etc/ant_version`

	if [ ${nVer} -lt ${oVer} ]; then
		echo "RUNME: Cannot Downgrade!!!" >> /tmp/upgrade_result
		exit 4
	fi	
fi


if [ $ret -eq 1 ];then
    cd ./xilinx
    
    if [ ! -e /dev/ubi_ctrl ];then
            echo "File system isn't UBI, Please update ubi package first!" >> /tmp/upgrade_result
            cd $path
            rm -rf *.tar.gz
            exit 1
    fi
    
    if [ -e BOOT.bin ]; then
            flash_erase /dev/mtd0 0x0 0x80 >/dev/null 2>&1
            nandwrite -p -s 0x0 /dev/mtd0 ./BOOT.bin >/dev/null 2>&1
            rm -rf BOOT.bin
    fi

    if [ -e devicetree.dtb ]; then
            flash_erase /dev/mtd0 0x1020000 0x1 >/dev/null 2>&1
            nandwrite -p -s 0x1020000 /dev/mtd0 ./devicetree.dtb >/dev/null 2>&1
            rm devicetree.dtb
    fi

    if [ -e uImage ]; then 
            flash_erase /dev/mtd0 0x1100000 0x40 >/dev/null 2>&1
            nandwrite -p -s 0x1100000 /dev/mtd0 ./uImage >/dev/null 2>&1
            rm uImage
    fi

#    if [ -e rootfs.jffs2 ]; then
#            if [ -f /dev/mtd3 ];then
#            flash_erase /dev/mtd2 0x0 0x1E0 >/dev/null 2>&1
#            else
#                flash_erase /dev/mtd2 0x0 0x280 >/dev/null 2>&1
#            fi
#            nandwrite -p -s 0x0 /dev/mtd2 ./rootfs.jffs2 >/dev/null 2>&1
#           rm rootfs.jffs2
#    fi

    ubiattach /dev/ubi_ctrl -m 2
    mount -t ubifs ubi1:rootfs /mnt/upgrade
    
    cd /mnt/upgrade/upgrade
    rm -rf /mnt/upgrade/upgrade/*
    cd $path

    if [ -e ./xilinx/angstrom_rootfs.jffs2 ];then
        md5=`md5sum ./xilinx/angstrom_rootfs.jffs2 | awk {'print $1'}`
        md5_r=`cat ubi_info`
        if [ $md5 == $md5_r ];then
            cp -rf ./xilinx/angstrom_rootfs.jffs2 /mnt/upgrade/upgrade
            if [ -f /dev/mtd3 ];then
                flash_erase /dev/mtd3 0 0xa0 >/dev/null 2>&1
            fi
        fi
    fi
    flash_erase /dev/mtd0 0x1040000 0x1 >/dev/null 2>&1
    nandwrite -p -s 0x1040000 /dev/mtd0 ./xilinx/upgrade-marker.bin >/dev/null 2>&1

    sync

    umount /mnt/upgrade
    ubidetach -d 1 /dev/ubi_ctrl
    
else
    echo "this is not for c5" >> /tmp/upgrade_result
fi
 
rm -rf *.tar.gz


#/sbin/reboot -f &
