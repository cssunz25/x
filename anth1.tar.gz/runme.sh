#!/bin/sh

if [ ! -f update.tar.gz ]; then
	echo "update.tar.gz not found"
	exit 1
fi

echo "Verifying update.tar.gz signature"
openssl dgst -sha256 -verify sign-public.pem \
	-signature update.tar.gz.sig update.tar.gz #> /dev/null 2>&1

if [ $? -ne 0 ]; then
	echo "Invalid signature for update.tar.gz"
	exit 1
fi

tar -xzf update.tar.gz -C /

echo "+++++++++++++++++++++++++++"

if [ ! -f sign-public.pem ]; then
	echo "sign-public.pem not found"
	exit 1
fi

if [ ! -f sign-public.pem.sig ]; then
	echo "sign-public.pem.sig not found"
	echo 1
fi

if [ -f /etc/ah.pem ]; then
	openssl dgst -sha256 -verify /etc/ah.pem \
		-signature sign-public.pem.sig sign-public.pem #> /dev/null 2>&1

	if [ $? -ne 0 ]; then
		echo "Invalid signature for sign-public.pem"
		exit 1
	fi
fi

echo "+++++++++++++++++++++++++++"

echo "Run the cleanup and install Anthill"

if [ -f "/sbin/ahmonitor.sh" ]
then
	rm "/sbin/ahmonitor.sh"
fi

echo "Kill process monitorcg"
killall -9 monitorcg

if [ -f "/etc/init.d/ahagent.sh" ]
then
	rm "/etc/init.d/ahagent.sh"
fi

if [ -f "/etc/init.d/init_ctrlbd.sh" ]
then
	rm "/etc/init.d/init_ctrlbd.sh"
fi

if [ -f "/etc/rcS.d/S03init_ctrlbd.sh" ]
then
	rm "/etc/rcS.d/S03init_ctrlbd.sh"
fi

if [ -f "/usr/bin/ahagent" ]
then
	mv "/usr/bin/ahagent" "/usr/bin/ahagent_old"
fi

if [ -f "/etc/rcS.d/S02mountdevtmpfs.sh" ]
then
	rm "/etc/rcS.d/S02mountdevtmpfs.sh"
fi

if [ -f "/usr/bin/compile_time" ]
then
	grep -q "3.8.7" "/usr/bin/compile_time"
	if [ $? -eq 0 ]
	then
		cp "/etc/init.d/bitmainer_setup_3.8.7.sh" "/etc/init.d/bitmainer_setup.sh" -f
		cp "/etc/init.d/bmminer_3.8.7.sh" "/etc/init.d/bmminer.sh" -f
	fi
fi

rm "/etc/init.d/bitmainer_setup_3.8.7.sh"
rm "/etc/init.d/bmminer_3.8.7.sh"

if [ -f "/etc/rcS.d/S37bitmainer_setup.sh" ]
then
	rm "/etc/rcS.d/S37bitmainer_setup.sh"
fi

if [ -f "/etc/rcS.d/S70bmminer.sh" ]
then
	rm "/etc/rcS.d/S70bmminer.sh"
fi

echo "Kill process if ahagent working!"
killall -9 ahagent

if [ -f "/usr/bin/ahagent_old" ]
then
	rm "/usr/bin/ahagent_old"
fi

if [ -f "/etc/ssl/certs/letsencryptauthorityx3.pem" ]
then
	rm "/etc/ssl/certs/letsencryptauthorityx3.pem"
fi

if [ -f "/etc/rcS.d/S71agent.sh" ]
then
	rm "/etc/rcS.d/S71agent.sh"
fi

if [ -f "/etc/rcS.d/S72agent_monitor.sh" ]
then
	rm "/etc/rcS.d/S72agent_monitor.sh"
fi

echo "create symbolik links"

ln -s "/etc/init.d/mountdevtmpfs.sh" "/etc/rcS.d/S02mountdevtmpfs.sh"
ln -s "/etc/init.d/bitmainer_setup.sh" "/etc/rcS.d/S37bitmainer_setup.sh"
ln -s "/etc/init.d/bmminer.sh" "/etc/rcS.d/S70bmminer.sh"
ln -s "/etc/init.d/agent.sh" "/etc/rcS.d/S71agent.sh"
ln -s "/etc/init.d/agent_monitor.sh" "/etc/rcS.d/S72agent_monitor.sh"

echo "remove libs"

if [ -f "/usr/lib/libcurl.so" ]
then
	rm "/usr/lib/libcurl.so"
fi

if [ -f "/usr/lib/libcurl.so.4" ]
then
	rm "/usr/lib/libcurl.so.4"
fi

if [ -f "/usr/lib/libcurl.so.4.5.0" ]
then
	rm "/usr/lib/libcurl.so.4.5.0"
fi

if [ -f "/usr/lib/libjansson.so" ]
then
	rm "/usr/lib/libjansson.so"
fi

if [ -f "/usr/lib/libjansson.so.4" ]
then
	rm "/usr/lib/libjansson.so.4"
	ln -s "/usr/lib/libjansson.so.4.5.0" "/usr/lib/libjansson.so.4"
fi

if [ -f "/usr/lib/libjansson.so.4.11.0" ]
then
	rm "/usr/lib/libjansson.so.4.11.0"
fi

if [ -f "/usr/lib/libmbedcrypto.so" ]
then
	rm "/usr/lib/libmbedcrypto.so"
fi

if [ -f "/usr/lib/libmbedcrypto.so.2.13.1" ]
then
	rm "/usr/lib/libmbedcrypto.so.2.13.1"
fi

if [ -f "/usr/lib/libmbedcrypto.so.3" ]
then
	rm "/usr/lib/libmbedcrypto.so.3"
fi

if [ -f "/usr/lib/libmbedtls.so" ]
then
	rm "/usr/lib/libmbedtls.so"
fi

if [ -f "/usr/lib/libmbedtls.so.2.13.1" ]
then
	rm "/usr/lib/libmbedtls.so.2.13.1"
fi

if [ -f "/usr/lib/libmbedtls.so.12" ]
then
	rm "/usr/lib/libmbedtls.so.12"
fi

if [ -f "/usr/lib/libmbedx509.so" ]
then
	rm "/usr/lib/libmbedx509.so"
fi

if [ -f "/usr/lib/libmbedx509.so.0" ]
then
	rm "/usr/lib/libmbedx509.so.0"
fi

if [ -f "/usr/lib/libmbedx509.so.2.13.1" ]
then
	rm "/usr/lib/libmbedx509.so.2.13.1"
fi

if [ -f "/usr/lib/libuv.so" ]
then
	rm "/usr/lib/libuv.so"
fi

if [ -f "/usr/lib/libuv.so.1" ]
then
	rm "/usr/lib/libuv.so.1"
fi

if [ -f "/usr/lib/libuv.so.1.0.0" ]
then
	rm "/usr/lib/libuv.so.1.0.0"
fi

if [ -f "/usr/lib/libwebsockets.so" ]
then
	rm "/usr/lib/libwebsockets.so"
fi

if [ -f "/usr/lib/libwebsockets.so.16" ]
then
	rm "/usr/lib/libwebsockets.so.16"
fi

if [ -f "/usr/lib/libz.so" ]
then
	rm "/usr/lib/libz.so"
fi

if [ -f "/usr/lib/llibz.so.1" ]
then
	rm "/usr/lib/libz.so.1"
fi

if [ -f "/usr/lib/libz.so.1.2.11" ]
then
	rm "/usr/lib/libz.so.1.2.11"
fi

if [ -f "/usr/lib/libform.so" ]
then
	rm "/usr/lib/libform.so"
fi

if [ -f "/usr/lib/libform.so.5" ]
then
	rm "/usr/lib/libform.so.5"
fi

if [ -f "/usr/lib/libform.so.5.9" ]
then
	rm "/usr/lib/libform.so.5.9"
fi

if [ -f "/usr/lib/libmenu.so" ]
then
	rm "/usr/lib/libmenu.so"
fi

if [ -f "/usr/lib/libmenu.so.5" ]
then
	rm "/usr/lib/libmenu.so.5"
fi

if [ -f "/usr/lib/libmenu.so.5.9" ]
then
	rm "/usr/lib/libmenu.so.5.9"
fi

if [ -f "/usr/lib/libncurses.so" ]
then
	rm "/usr/lib/libncurses.so"
fi

if [ -f "/usr/lib/libncurses.so.5" ]
then
	rm "/usr/lib/libncurses.so.5"
fi

if [ -f "/usr/lib/libncurses.so.5.9" ]
then
	rm "/usr/lib/libncurses.so.5.9"
fi

if [ -f "/usr/lib/libwebsockets.so.15" ]
then
	rm "/usr/lib/libwebsockets.so.15"
fi

if [ -f "/usr/lib/libz.so.1" ]
then
	rm "/usr/lib/libz.so.1"
fi

echo "end remove libs"

echo "Finish the script and install Anthill"

echo "+++++++++++++++++++++++++++"

echo "Delete temp files"

rm "./update.tar.gz"

rm "./runme.sh"

rm "./cleanup.sh"

echo "Finish delete temp files"

echo "+++++++++++++++++++++++++++"

if [ -n "$1" ] && ! [ -f "/config/anthill.json" ]
then
	echo "Create file /config/anthill.json api_key = $1"
	echo -e "{\n  \"api_key\": \"$1\"\n}" > "/config/anthill.json"
fi

if [ -f "anthill.json" ] && ! [ -f "/config/anthill.json" ]
then
	echo "Copy file anthill.json to /config/anthill.json"
	mv "anthill.json" "/config/anthill.json"
fi

echo "+++++++++++++++++++++++++++"

sync

tar -xzf up.tar.gz -C / 


# Some vnish's firemware requires it
# to finigh update properly
#exit 0
